//
//  RecieptView.swift
//  HuliPizza
//
//  Created by Steven Lipton on 3/6/25.
//

import SwiftUI

struct ReceiptView: View {
    var orders:OrderModel
    @Binding var presentView:Bool
    var body: some View {
        VStack{
            
            HStack{
                Spacer()
                Text("Receipt")
                .surfboardTitle
            }
                .surfboardBackground
            Grid{
                GridRow{
                    Text("Item")
                    Text("Price")
                    Text("Quantity")
                    Text("Ext Price")
                   
                }
                ForEach(orders.orderItems){ item in
                    GridRow{
                        Text(item.item.name)
                        Text(item.item.price,format:.currency(code:"usd"))
                        Text(item.quantity,format:.number)
                        Text(item.extPrice,format:.currency(code:"usd"))
                    }
                }
                GridRow{
                    Text("Total")
                    Text(orders.orderTotal,format:.currency(code: "usd"))
                }
            }
            Spacer()
            Button("Okay"){
                presentView = false
            }
                .appButtonStyleModifier(backgroundColor: .sky)
            
        }
       .appBackground
    }
    
}

#Preview {
    ReceiptView(orders:OrderModel(), presentView:.constant(true) )
}
